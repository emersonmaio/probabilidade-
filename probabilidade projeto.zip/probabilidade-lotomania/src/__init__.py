"""Lotomania statistical research package."""
